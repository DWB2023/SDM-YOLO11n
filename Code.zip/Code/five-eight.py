


'''
        "  5——8  "
        将其中的 YOLO 格式标签（5个参数）转换为旋转框格式（8个参数）。下面的程序将读取文件夹中的每个 .txt 文件，解析每一行标签，
    将其从 (class_id, x_center, y_center, width, height) 格式转换为 (class_id, x0, y0, x1, y1, x2, y2, x3, y3) 格式，
    并将结果保存回文件或另存到新的文件夹中。

'''


import os
import math

# 旋转框计算函数
def yolo_to_corners(class_id, x_center, y_center, width, height, theta=0):
    half_width = width / 2
    half_height = height / 2

    x0 = x_center - half_width
    y0 = y_center - half_height
    x1 = x_center + half_width
    y1 = y_center - half_height
    x2 = x_center + half_width
    y2 = y_center + half_height
    x3 = x_center - half_width
    y3 = y_center + half_height

    # 旋转矩形（如果没有旋转，theta 为0）
    if theta != 0:
        x0, y0 = rotate_point(x_center, y_center, x0, y0, theta)
        x1, y1 = rotate_point(x_center, y_center, x1, y1, theta)
        x2, y2 = rotate_point(x_center, y_center, x2, y2, theta)
        x3, y3 = rotate_point(x_center, y_center, x3, y3, theta)

    return [class_id, x0, y0, x1, y1, x2, y2, x3, y3]

# 旋转点函数
def rotate_point(cx, cy, x, y, angle):
    cos_theta = math.cos(angle)
    sin_theta = math.sin(angle)

    x_shifted = x - cx
    y_shifted = y - cy

    x_new = cos_theta * x_shifted - sin_theta * y_shifted + cx
    y_new = sin_theta * x_shifted + cos_theta * y_shifted + cy

    return x_new, y_new

# 处理文件夹中的所有标签文件
def process_labels_folder(input_folder, output_folder, theta=0):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for filename in os.listdir(input_folder):
        # 跳过 classes.txt 文件
        if filename == "classes.txt":
            print(f"Skipping file: {filename}")
            continue

        if filename.endswith(".txt"):
            input_file_path = os.path.join(input_folder, filename)
            output_file_path = os.path.join(output_folder, filename)

            with open(input_file_path, "r") as infile, open(output_file_path, "w") as outfile:
                for line in infile:
                    parts = line.strip().split()
                    class_id = int(parts[0])
                    x_center = float(parts[1])
                    y_center = float(parts[2])
                    width = float(parts[3])
                    height = float(parts[4])

                    # 转换标签
                    converted_label = yolo_to_corners(class_id, x_center, y_center, width, height, theta)
                    converted_label_str = " ".join(map(str, converted_label))

                    # 写入转换后的标签
                    outfile.write(converted_label_str + "\n")

            print(f"Processed file: {filename}")


# 主函数，指定输入和输出文件夹路径
if __name__ == "__main__":
    # input_folder = r"Z:\SYP_YWJC\ultralytics-main1\data\test_datasets8\labels1"   # 替换为包含原始标签的文件夹路径
    # output_folder = r"Z:\SYP_YWJC\ultralytics-main1\data\test_datasets8\labels2"  # 替换为保存转换后标签的文件夹路径

    # input_folder = r"E:\Code\Detect_Datasets\DATA\datasets2\labels-test\train"   # 替换为包含原始标签的文件夹路径
    # output_folder = r"E:\Code\Detect_Datasets\DATA\datasets2\labels-test\test"  # 替换为保存转换后标签的文件夹路径

    input_folder = r"E:\Code\Detect_Datasets\DATA\datasets3\data2\labels\train4"   # 替换为包含原始标签的文件夹路径
    output_folder = r"E:\Code\Detect_Datasets\DATA\datasets3\data2\labels\train8"  # 替换为保存转换后标签的文件夹路径

    # 处理所有文件
    process_labels_folder(input_folder, output_folder, theta=0)  # 旋转角度可以根据需要调整


# # # ===================================================================================


