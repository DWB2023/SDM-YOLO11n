import os
import shutil


def move_files_by_extension(source_dir, target_dir):
    # 如果目标文件夹不存在，则创建
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)

    # 遍历源文件夹中的所有文件
    for filename in os.listdir(source_dir):
        file_path = os.path.join(source_dir, filename)

        # 确保是文件而不是文件夹
        if os.path.isfile(file_path):
            # 获取文件扩展名
            file_extension = filename.split('.')[-1]

            # 创建按扩展名命名的文件夹
            extension_folder = os.path.join(target_dir, file_extension)
            if not os.path.exists(extension_folder):
                os.makedirs(extension_folder)

            # 将文件移动到对应扩展名的文件夹中
            shutil.move(file_path, os.path.join(extension_folder, filename))
            print(f"已移动: {filename} 到 {extension_folder}")


# 设置源文件夹和目标文件夹路径
source_directory = 'E:\Code\Detect_Datasets\DATA\datasets3\data4\images'
target_directory = 'E:\Code\Detect_Datasets\DATA\datasets3\data4\labels'

# 调用函数执行操作
move_files_by_extension(source_directory, target_directory)
