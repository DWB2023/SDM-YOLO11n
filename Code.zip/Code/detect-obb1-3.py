# -*- coding: utf-8 -*-
"""
@File ：detect.py
@IDE ：PyCharm
@=======================================
在推理阶段，mode模式为预测, mode= predict，
模型使用训练完成的权重文件: runs/train/exp/weights/best.pt，
source表示需要预测的图像文件路径, source='images',中存放了准备预测的图像。
"""


# import warnings
# warnings.filterwarnings('ignore')
# warnings.filterwarnings("ignore", category=UserWarning, message=".*libpng.*")
import time

from pyttsx3 import engine
from scipy.constants import lb

from ultralytics import YOLO
import cv2
import math
import pyttsx3
import numpy as np
from scipy.signal import medfilt
import torch
import threading
device = "cuda:0" if torch.cuda.is_available() else "cpu"
from vidgear.gears import CamGear

def calculate_LdownLup(coords4):
    # 四个顶点坐标
    x1, y1, x2, y2, x3, y3, x4, y4 = coords4
    # 计算距离
    distance = math.sqrt((x4 - x1) ** 2 + (y4 - y1) ** 2)
    return distance

# 语音报警模块：
def speak(text):
    """语音播报函数"""
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

def process_image_txt():
    global detect_aim_num
    xswb = filtered_result1.copy()
    if xswb and detect_aim_num >= 1:
        for ii3, result in enumerate(xswb):
            if result != 0:
                volume_of_liquid = result * 100  # 使用 filtered_result 中的值
                text_name = "text{}".format(ii3 + 1)  # 使用索引创建不同的文本变量名
                globals()[text_name] = "{}{} {}{:.0f}{}".format("left_", ii3 + 1, "Volume of Liquid: ",
                                                                volume_of_liquid, "%")
                org = (0, 35 + ii3 * 35)  # 设置不同的垂直位置
                font = cv2.FONT_HERSHEY_SIMPLEX
                fontScale = 1
                color = (255, 0, 0)  # 设置不同的文本颜色，格式为 (B, G, R)
                # color = (128, 0, 128) # 设置不同的文本颜色，格式为 (B, G, R)
                thickness = 2  # 文本线条粗细
                cv2.putText(img, globals()[text_name], org, font, fontScale, color, thickness)
    else:
        text = '********'  # 在图像上面显示的文本内容
        org = (0, 35)
        font = cv2.FONT_HERSHEY_SIMPLEX
        fontScale = 1
        color = (255, 0, 0)  # 设置文本颜色，格式为 (B, G, R)
        thickness = 2  # 文本线条粗细
        cv2.putText(img, text, org, font, fontScale, color, thickness)
def show_video_frameb():
    global dxbzw
    global img
    global detect_aim_num
    global syyl_bfb60
    global filtered_result0
    global filtered_result1
    global engine_idle
    while 1:
        # print(111)
        syyl_bfb = []
        LdLu = []
        # syyl_bfb60 = []
        # filtered_data1 = []
        img0 = camera.read()
        img = cv2.resize(img0, (800,600))
        # time.sleep(0.1)
        if img is not None:
            # img = cv2.resize(img, (640, 480))  # 加一条判断语句，修改图像大小
            showimg = img
            process_image_txt()  # 在图像上面编辑文字,直接调用函数（在图像左上角依次显示图像中液位的占比）
            results = model.predict(
                source=showimg,  # 摄像头捕捉的帧帧画面
                save=False,
                imgsz=640,
                device='cuda:0',
                conf=0.75,
                iou=0.45,
                show=False,
                save_txt=False,
                save_crop=False,
                line_width=3,
                visualize=False,
                augment=False,
                agnostic_nms=False,
                retina_masks=False,
                verbose=False,
            )

            # 获取旋转矩形框（OBB）坐标
            for result in results:
                if result.obb.xyxyxyxy is not None:
                    bbox = result.obb.xyxyxyxy.cpu().numpy()
                    if len(bbox) > 0:
                        flattened = bbox.flatten()
                        coord1 = flattened.reshape(-1, 8)  # 将一维列表分成每行8个数据
                        # print(" *排序前* 图像中各个矩形框的坐标信息：", coord1)  # 将图像中的所有图像的【四个顶点x1y1x2y2x3y3x4y4】为一体，排成一行
                        if len(bbox) > 1:
                            # 按子列表的第一个元素进行排序
                            coord1 = sorted(coord1, key=lambda x: x[0])  # [array([240.06, 360.5, 316.55, 362.34, 318.43, 284.52, 241.93, 282.67], dtype=float32), array([ ......
                            # 转换为普通列表
                            coord1 = [arr.tolist() for arr in coord1]  # [[子列表] [子列表] [子列表] [子列表]]
                            # 保留两位小数（四舍五入）
                            coord1 = [[round(num, 2) for num in sublist] for sublist in coord1]
                            # 输出排序后的列表
                            # print(" *排序后* 图像中各个矩形框的坐标信息：", coord1)   # 将各个目标检测框的坐标信息

                        # 计算各个矩形边界框的面积并打印
                            for i, rect in enumerate(coord1):  # 排序后的各个矩形框的面积 ！！！
                                LdownLup = calculate_LdownLup(rect)  # 左上与左下等效高度！！！
                                LdLu.append(LdownLup)

                            for i1 in range(len(coord1) - 1):
                                diff = abs(coord1[i1 + 1][0] - coord1[i1][0])  # 计算相邻子列表第一个元素的差值
                                if diff <= 20:
                                    syyl = ((LdLu[i1 + 1] - LdLu[i1] * 0.23) / (LdLu[i1] - LdLu[i1] * 0.23)) if (LdLu[i1 + 1] / LdLu[i1] < 1) else (
                                                (LdLu[i1] - LdLu[i1 + 1] * 0.23) / (LdLu[i1 + 1] - LdLu[i1 + 1] * 0.23))
                                    # print(" ###图像中各个输液瓶的输液余量（以百分比的形式显示）：", syyl)
                                    syyl_bfb.append(syyl)
                            # print(" 输液余量(以百分比的形式显示【纯数据】)：", syyl_bfb)  # 得到各个输液瓶中药液的剩余量（均以百分比的形式显示输液余量）
                            # 若列表长度小于5，则补0
                            while len(syyl_bfb) < 5:
                                syyl_bfb.append(0)
                            # print(" 输液余量（以百分比的形式显示【补零后】）：", syyl_bfb)  # 补0之后的列表数据，例如[ 数据1，数据2，数据3, 0, 0 ]
                            syyl_bfb60.append(syyl_bfb)  # [ [子列表1] [子列表2] [子列表3] [...] [...] [...] [子列表58] [子列表59] [子列表60] ]  # 追加到60个子列表
                            # print(" 输液余量列表的长度：",len(syyl_bfb60))
                            # print(" 输液余量（以百分比的形式显示 【0-60】 ）：", syyl_bfb60) #
                            # print(len(self.syyl_bfb60))
                            if len(syyl_bfb60) >= 60:
                                # 将60组数据进行中值滤波      确保 data 是 NumPy 数组
                                data_array = np.array(syyl_bfb60)  # 形状为 (60, 5)
                                # 进行中值滤波（窗口大小3）
                                filtered_data = np.apply_along_axis(medfilt, axis=0, arr=data_array, kernel_size=3)
                                # 计算最终的中值（取所有行的中位数）
                                final_median = np.median(filtered_data, axis=0)
                                # print("******打印出中值滤波后的结果（含0）：", final_median)   # 输出: [0.78 0.41 0 0 0]  起始阶段，数据为空
                                data = np.array(final_median)
                                filtered_data = data[data != 0]  # 只保留非零元素
                                # print("######1 打印出中值滤波后的结果（不含0）：", filtered_data)# 输出: [0.78 0.41] # 后续用于显示界面 【data1, data2, ...】
                                filtered_result1 = filtered_data.copy()
                                # print("######2 打印出中值滤波后的结果（不含0）：", filtered_data1)
                                filtered_result11 = np.array(filtered_result1.copy())
                                filtered_result1 = np.around(filtered_result11, 2)
                                filtered_result1 = filtered_result1.tolist()
                                detect_aim_num = len(filtered_result1)
                                engine_idle = 1
                                if filtered_result0 != filtered_result1:
                                    dwtxt('sypym.txt', time.strftime("%Y%m%d %H:%M:%S ") + str(filtered_result1))
                                    filtered_result0 = filtered_result1.copy()
                                    dxbzw = 1
                                syyl_bfb60 = []  # 将列表中的原始数据清空.空列表
                    else:
                        detect_aim_num=0
                    img = results[0].plot()
                    # showimgc = showimg.copy()
        else:
            print("您好，未有检测到图像，请检查摄像头是否正常打开！")
def ymbb(kg0,ys0,tdbl):
    global filtered_result1
    global engine_idle
    global engine
    i=0
    while True:
        i=i+1
        print(i)
        # if kg0==1 and len(filtered_result1)!=0:
        if kg0==1 and engine_idle==1:
            for numi,sypymbli in enumerate(filtered_result1,1):
                message = f"您好，第{numi}个输液瓶的液位比例为{sypymbli * 100:.0f}%"
                engine_idle = 0
                engine.say(message)
                engine.runAndWait()
                # engine_idle = 1
            # print(tdbl/100.0)
            if len(filtered_result1)!=0:
                if min(filtered_result1)<= tdbl/100.0:
                    time.sleep(3)
            else:
                time.sleep(ys0)
        else:
            time.sleep(ys0)

def CurrentImg():
    global camera
    global img
    while 1:
        # img0 = camera.read()
        # img = cv2.resize(img0, (800, 600))
        # # cv2.namedWindow('YOLO11 Real-time Detection', cv2.WINDOW_NORMAL)
        cv2.imshow('YOLO11 Real-time Detection', img)
        # 按下 'q' 键退出循环
        if cv2.waitKey(1) & 0xFF == ord('q'):
            camera.stop()
            # cap.release()
            cv2.destroyAllWindows()
            break
    # 释放摄像头资源并关闭所有窗口
def dwtxt(filename, strdata):
    f = open(filename, mode='a+')
    with open(filename, "r+") as f:
        old = f.read()
        f.seek(0)
        f.write(strdata + '\n')
        f.write(old)
        f.close()

if __name__ == '__main__':
    LdLu = []
    syyl_bfb = []
    syyl_bfb60 = []
    Index = 0
    filtered_data1 = []
    filtered_result1=[]
    syyl_bfb60 = []
    filtered_result0 = []
    engine_idle = 1
    kg=1
    ys=5
    tdbl=10
    xckg=1
    dxbzw=0
    detect_aim_num=0
    img= np.zeros((640, 640, 3), dtype=np.uint8, order='C')
    # 加载YOLO网络模型
    model = YOLO(r'.\runs\train\exp24\weights\best.pt')  # 加载网络模型
    # 摄像头的选择：（1）本地摄像头 （2）网络摄像头
    # url = 0   # 使用本地摄像头
    # url = "rtsp://admin:zhxf3333@192.168.1.100/Streaming/Channels/2"  # 网络摄像头  使用模式2不会太卡
    url = "rtsp://admin:zhxfqwe111@111.115.7.66/Streaming/Channels/2"
    engine = pyttsx3.init()
    camera = CamGear(source=url).start()

    CurImg2 = threading.Thread(target=CurrentImg)
    CurImg2.daemon = True
    CurImg2.start()

    CurImg1 = threading.Thread(target=show_video_frameb)
    CurImg1.daemon = True
    CurImg1.start()
    # time.sleep(1)
    # CurImg3 = threading.Thread(target=ymbb, args=(kg, ys, tdbl))
    # CurImg3.daemon = True
    # CurImg3.start()
    ymbb(1,5,10)
    # show_video_frameb()
    # while 1:
    #     pass



# ============================== 2025 06 05 final =========




