# -*- coding: utf-8 -*-
"""
@File ：detect.py
@IDE ：PyCharm
@=======================================
在推理阶段，mode模式为预测, mode= predict，
模型使用训练完成的权重文件: runs/train/exp/weights/best.pt，
source表示需要预测的图像文件路径, source='images',中存放了准备预测的图像。
"""

import warnings
warnings.filterwarnings('ignore')
warnings.filterwarnings("ignore", category=UserWarning, message=".*libpng.*")
from ultralytics import YOLO
import cv2
import math
import pyttsx3
import numpy as np
from scipy.signal import medfilt
import torch
device = "cuda:0" if torch.cuda.is_available() else "cpu"

# 计算四边形的面积
# def polygon_area(points):
#     # 计算四边形的面积，输入为 4 个顶点的 (x, y) 坐标列表
#     points = np.array(points).reshape((4, 2))  # 转换为 4x2 形状的数组
#     # 使用 Shoelace 公式计算多边形面积
#     x = points[:, 0]
#     y = points[:, 1]
#     area = 0.5 * abs(np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1)))
#     return area
# # ======================================================================
# 计算四边形的最长边
# def calculate_long_side(coords4):
#     # 四个顶点坐标
#     x1, y1, x2, y2, x3, y3, x4, y4 = coords4
#     # 计算四条边的长度
#     d1 = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
#     d2 = math.sqrt((x3 - x2) ** 2 + (y3 - y2) ** 2)
#     d3 = math.sqrt((x4 - x3) ** 2 + (y4 - y3) ** 2)
#     d4 = math.sqrt((x1 - x4) ** 2 + (y1 - y4) ** 2)
#     # 取最长的边
#     long_side = max(d1, d2, d3, d4)
#     return long_side


def calculate_LdownLup(coords4):
    # 四个顶点坐标
    x1, y1, x2, y2, x3, y3, x4, y4 = coords4
    # 计算距离
    distance = math.sqrt((x4 - x1) ** 2 + (y4 - y1) ** 2)
    return distance





# 语音报警模块：
def speak(text):
    """语音播报函数"""
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()
def liquid_level_alert(level):
    """
    液位提醒函数
    :param level: 液体剩余百分比 (0~100)  特殊位置的输液余量提醒（75% 50% 25% 10%）
    """
    if level >= 60 and level <= 86:
        speak("当前液位为75%，较为充足，请放心使用！")
    elif level >= 49 and level <= 51:
        speak("当前液位为50%，较为充足，请放心使用！")
    elif level >= 24 and level <= 26:
        speak("警告！液位下降到25%，请注意监测输液！")
    elif level >= 9 and level <= 11:
        speak("警告！液位下降到10%，请及时准备更换！")



if __name__ == '__main__':
    jxk_mj = []
    syyl_bfb = []
    syyl_bfb60 = []
    Index = 0
    filtered_data1 = []
    # 加载YOLO网络模型
    model = YOLO(r'E:\Code\Detect_Datasets\YOLO\ultralytics-8.3.2\runs\train\exp18\weights\65536\best.pt')  # 加载网络模型
    # 摄像头的选择：（1）本地摄像头 （2）网络摄像头
    url = 0   # 使用本地摄像头
    # url = "rtsp://admin:zhxf3333@192.168.1.100/Streaming/Channels/2"  # 网络摄像头  使用模式2不会太卡
    # url = "rtsp://admin:zhxfqwe111@111.115.7.66/Streaming/Channels/2"
    cap = cv2.VideoCapture(url)
    if not cap.isOpened():
        print("Error: 无法打开摄像头")
        exit()
    while True:
        ret, frame = cap.read() # frame 里面是一帧帧图像
        if not ret:
            print("Error: 无法读取摄像头数据")
            break

        # 使用训练的最佳YOLO11网络模型进行实时预测：
        results = model.predict(
            source=frame,  # 摄像头捕捉的帧帧画面
            save=False,
            imgsz=640,
            device='0',
            conf=0.65,
            iou=0.45,
            show=False,
            save_txt=False,
            save_crop=False,
            line_width=3,
            visualize=False,
            augment=False,
            agnostic_nms=False,
            retina_masks=False,
            verbose=False,
        )





        # 获取旋转矩形框（OBB）坐标
        for result in results:
            print(result)
            if result.obb.xyxyxyxy is not None:
                bbox = result.obb.xyxyxyxy.cpu().numpy()
                if len(bbox) > 0:
                    flattened = bbox.flatten()
                    coord1 = flattened.reshape(-1, 8) # 将一维列表分成每行8个数据
                    print(" *排序前* 图像中各个矩形框的坐标信息：", coord1)  # 将图像中的所有图像的【四个顶点x1y1x2y2x3y3x4y4】为一体，排成一行
                    if len(bbox) > 1:
                        # 按子列表的第一个元素进行排序
                        coord1 = sorted(coord1, key=lambda x: x[0])  # [array([240.06, 360.5, 316.55, 362.34, 318.43, 284.52, 241.93, 282.67], dtype=float32), array([ ......
                        # 转换为普通列表
                        coord1 = [arr.tolist() for arr in coord1]    # [[子列表] [子列表] [子列表] [子列表]]
                        # 保留两位小数（四舍五入）
                        coord1 = [[round(num, 2) for num in sublist] for sublist in coord1]
                        # 输出排序后的列表
                        print(" *排序后* 图像中各个矩形框的坐标信息：", coord1)   # 将各个目标检测框的坐标信息



                    # 计算各个矩形边界框的面积并打印
                    for i, rect in enumerate(coord1):  # 排序后的各个矩形框的面积 ！！！
                        # area = polygon_area(rect)    # 面积！！！
                        long_side = calculate_LdownLup(rect)  # 最长边！！！   等效高度！！！

                        # print(f"矩形 {i + 1} 的面积: {area:.2f}")
                        jxk_mj.append(long_side)
                    # print("图像中各个矩形框的面积为：", jxk_mj) # 循环结束后，jxk_mj里面存储所有矩形框的面积.[ [], [], [] ] 获取到图像中各个矩形框的面积值

                    for i1 in range(len(coord1)-1):
                        diff = abs(coord1[i1+1][0] - coord1[i1][0])  # 计算相邻子列表第一个元素的差值
                        if diff <= 20:
                            syyl = ( (jxk_mj[i1+1]-jxk_mj[i1]*0.23) / (jxk_mj[i1]-jxk_mj[i1]*0.23) ) if (jxk_mj[i1+1] / jxk_mj[i1] < 1) else ((jxk_mj[i1]-jxk_mj[i1+1]*0.23) / (jxk_mj[i1+1]-jxk_mj[i1+1]*0.23))
                            # print(" ###图像中各个输液瓶的输液余量（以百分比的形式显示）：", syyl)
                            syyl_bfb.append(syyl)
                    # print(" 输液余量(以百分比的形式显示【纯数据】)：", syyl_bfb)  # 得到各个输液瓶中药液的剩余量（均以百分比的形式显示输液余量）显示各个输液瓶中药液的剩余量
                    # syyl_bfb = []
                    # 若列表长度小于5，则补0
                    while len(syyl_bfb) < 5:
                        syyl_bfb.append(0)
                    # print(" 输液余量（以百分比的形式显示【补零后】）：", syyl_bfb)  # 补0之后的列表数据，例如[ 数据1，数据2，数据3, 0, 0 ]
                    syyl_bfb60.append(syyl_bfb) # [ [子列表1] [子列表2] [子列表3] [...] [...] [...] [子列表58] [子列表59] [子列表60] ]  # 追加到60个子列表
                    # print(" 输液余量（以百分比的形式显示 【0-60】 ）：", syyl_bfb60) #
                    Index = Index + 1
                    if Index >= 60:
                        # 将60组数据进行中值滤波      确保 data 是 NumPy 数组
                        data_array = np.array(syyl_bfb60)  # 形状为 (60, 5)
                        # 进行中值滤波（窗口大小3）
                        filtered_data = np.apply_along_axis(medfilt, axis=0, arr=data_array, kernel_size=3)
                        # 计算最终的中值（取所有行的中位数）
                        final_median = np.median(filtered_data, axis=0)
                        # print("******打印出中值滤波后的结果（含0）：", final_median)   # 输出: [0.78 0.41 0 0 0]  起始阶段，数据为空
                        data = np.array(final_median)
                        filtered_data = data[data != 0]  # 只保留非零元素
                        # print("######1 打印出中值滤波后的结果（不含0）：", filtered_data)# 输出: [0.78 0.41] # 后续用于显示界面 【data1, data2, ...】
                        filtered_data1 = filtered_data.copy()
                        print("######2 打印出中值滤波后的结果（不含0）：", filtered_data1)

                        Index = 0
                        syyl_bfb60 = []
                    # # 将列表中的原始数据清空.空列表. 一定要将数据清空 ！！！！！！
                    jxk_mj = []
                    syyl_bfb = []

            # 输液余量实时显示（以百分比的形式显示）
            if len(filtered_data1)!=0 and len(bbox) > 0:
                for ii1, value in enumerate(filtered_data1):
                    cv2.putText(frame, "Left-{} Volume of Liquid: {:.0f}%".format(ii1 + 1, value*100), (10, 30 * (ii1 + 1)), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)  # 绿色文本，字体大小 1，线宽 2
                    # # # # 语音报警函数的调用：实现输液余量信息的提醒！！！
                    # levels = filtered_data1
                    # for index1, value1 in enumerate(levels):
                    #     print('从左边数，第{}个输液瓶中的药液当前剩余{:.0f}%.'.format((index1+1), value1*100))
                    #     value1 = round(value1, 2)
                    #     liquid_level_alert(value1*100)  # 现在的问题是语音播放时，输液余量显示界面静止不动，播放完毕之后界面从新动起来！！！
                    #     # print('= ============================================================================================== =')

            else:
                cv2.putText(frame, "*********", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)  # 绿色文本，字体大小1，线宽2


        # 将预测结果绘制在帧上
        annotated_frame = results[0].plot()
        # 显示实时检测结果
        cv2.imshow('YOLOv8 Real-time Detection', annotated_frame)
        # 按下 'q' 键退出循环
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    # 释放摄像头资源并关闭所有窗口
    cap.release()
    cv2.destroyAllWindows()


# ============================== 2025 03 07 final =========

# 下一步：
#   1 函数化
#   2 多线程
#   3 简化程序
#   4


