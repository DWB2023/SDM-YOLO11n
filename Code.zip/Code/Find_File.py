'''
    在一个文件夹中查找所有与另一个文件夹中同名的文件，并将这些文件复制到一个新的文件夹中


'''

# === 含有后缀名！！！
# import os
# import shutil
#
# def find_and_copy_files(source_folder, target_folder, output_folder):
#     # 检查输出文件夹是否存在，如果不存在则创建
#     if not os.path.exists(output_folder):
#         os.makedirs(output_folder)
#
#     # 获取源文件夹和目标文件夹中的所有文件
#     source_files = set(os.listdir(source_folder))
#     target_files = set(os.listdir(target_folder))
#
#     # 找出两个文件夹中同名的文件
#     common_files = source_files.intersection(target_files)
#
#     # 复制同名文件到输出文件夹
#     for filename in common_files:
#         source_file_path = os.path.join(source_folder, filename)
#         target_file_path = os.path.join(target_folder, filename)
#         # 检查文件是否存在，避免错误
#         if os.path.isfile(source_file_path) and os.path.isfile(target_file_path):
#             shutil.copy(source_file_path, output_folder)
#             print(f"文件 {filename} 已复制到 {output_folder}")
#
# if __name__ == "__main__":
#     source_folder = r"Z:\Datasets_D\SYP_Datasets\Datasets3\detasets\labels"   # 替换为源文件夹路径
#     target_folder = r"E:\Code\Detect_Datasets\datasets\images"   # 替换为目标文件夹路径
#     output_folder = r"E:\Code\Detect_Datasets\datasets\labels"   # 替换为输出文件夹路径
#
#     find_and_copy_files(source_folder, target_folder, output_folder)


import os
import shutil


def find_and_copy_files(source_folder, target_folder, output_folder):
    # 检查输出文件夹是否存在，如果不存在则创建
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 获取源文件夹和目标文件夹中的所有文件
    source_files = set(os.listdir(source_folder))
    target_files = set(os.listdir(target_folder))

    # 只比较文件名（不包括扩展名）
    source_base_names = {os.path.splitext(f)[0] for f in source_files}
    target_base_names = {os.path.splitext(f)[0] for f in target_files}

    # 找出两个文件夹中同名（不包括后缀名）的文件
    common_base_names = source_base_names.intersection(target_base_names)

    # 复制同名文件到输出文件夹
    for base_name in common_base_names:
        # 查找源文件夹和目标文件夹中的实际文件路径
        source_file_path = next(f for f in source_files if os.path.splitext(f)[0] == base_name)
        target_file_path = next(f for f in target_files if os.path.splitext(f)[0] == base_name)

        # 获取文件的完整路径
        source_file_path = os.path.join(source_folder, source_file_path)
        target_file_path = os.path.join(target_folder, target_file_path)

        # 检查文件是否存在，避免错误
        if os.path.isfile(source_file_path) and os.path.isfile(target_file_path):
            # 复制文件到输出文件夹
            shutil.copy(source_file_path, output_folder)
            print(f"文件 {source_file_path} 已复制到 {output_folder}")


if __name__ == "__main__":
    # source_folder = r"Z:\Datasets_D\SYP_Datasets\Datasets3\detasets\labels"  # 替换为源文件夹路径
    # target_folder = r"E:\Code\Detect_Datasets\datasets\images"  # 替换为目标文件夹路径
    # output_folder = r"E:\Code\Detect_Datasets\datasets\labels"  # 替换为输出文件夹路径

    source_folder = r"E:\Code\Detect_Datasets\DATA\datasets2\labels-test\train"  # 替换为源文件夹路径
    target_folder = r"E:\Code\Detect_Datasets\DATA\datasets2\images1-test1"  # 替换为目标文件夹路径
    output_folder = r"E:\Code\Detect_Datasets\DATA\datasets2\labels1-test1"  # 替换为输出文件夹路径
    find_and_copy_files(source_folder, target_folder, output_folder)








