
'''
使用以下的 Python 程序来重新命名文件夹中的所有 .png 文件，按照 syp_0000001.png、syp_0000002.png 的格式依次命名

'''
# import os
# # 设置目标文件夹路径
# folder_path = r'E:\Code\Detect_Datasets\DATA\datasets1\images\test'  # 请替换为你的文件夹路径
#
# # 获取文件夹中的所有文件
# files = [f for f in os.listdir(folder_path) if f.endswith('.png')]
#
# # 排序文件，以确保按字母顺序或其他规则重新命名
# files.sort()
#
# # 重新命名文件
# for i, file in enumerate(files):
#     # 生成新文件名
#     new_name = f"syp_{i + 1117:05d}.png"
#
#     # 获取旧文件的完整路径和新文件的完整路径
#     old_path = os.path.join(folder_path, file)
#     new_path = os.path.join(folder_path, new_name)
#
#     # 重命名文件
#     os.rename(old_path, new_path)
#     print(f"Renamed: {file} -> {new_name}")
#
# print("Renaming completed.")




'''
使用以下 Python 程序来删除文件夹中所有包含“副本”字样的文件。

'''
import os
# 设置目标文件夹路径
folder_path = r'E:\Code\Detect_Datasets\DATA\datasets1\syp01'  # 请替换为你的文件夹路径
# 遍历文件夹中的所有文件
for file_name in os.listdir(folder_path):
    # 检查文件名中是否包含"副本"
    if '副本' in file_name:
        # 构造完整的文件路径
        file_path = os.path.join(folder_path, file_name)

        # 确保文件是一个文件而不是文件夹
        if os.path.isfile(file_path):
            # 删除文件
            os.remove(file_path)
            print(f"已删除文件: {file_name}")
print("删除完成。")



