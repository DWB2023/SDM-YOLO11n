'''
    查看 PyTorch 的版本以及其他相关信息, 快速查看 PyTorch 环境的配置信息

'''

import torch
import torchvision

def print_torch_info():
    print(f"PyTorch Version: {torch.__version__}") # 查看 PyTorch 版本
    print(f"CUDA Available: {torch.cuda.is_available()}") # 检查 CUDA 是否可用
    print(f"CUDA Version: {torch.version.cuda}") # 查看 CUDA 版本
    print(f"cuDNN Version: {torch.backends.cudnn.version()}") # 查看 cuDNN 版本
    # 如果有 GPU，则输出更多 GPU 信息
    if torch.cuda.is_available():
        print(f"Number of GPUs: {torch.cuda.device_count()}") # GPU 数量
        print(f"GPU Name: {torch.cuda.get_device_name(0)}") # GPU 名称
        print(f"GPU Memory Allocated: {torch.cuda.memory_allocated(0)} bytes") # 分配的 GPU 内存
        print(f"GPU Memory Cached: {torch.cuda.memory_reserved(0)} bytes") # 已缓存的 GPU 内存
    # 输出 torchvision 信息
    print(f"torchvision Version: {torchvision.__version__}") # 查看 torchvision 版本

if __name__ == "__main__":
    print_torch_info()

