# -*- coding: utf-8 -*-
"""
@ YOLOv11s 目标检测
@File ：trian.py
@IDE ：PyCharm

"""

import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    # model.load('yolo11n.pt') # 加载预训练权重,改进或者做对比实验时候不建议打开，因为用预训练模型整体精度没有很明显的提升
    # model = YOLO(model=r'E:\Code\Detect_Datasets\YOLO\ultralytics-8.3.2\ultralytics\cfg\models\11\yolov11s.yaml')   # 模型配置文件的路径
    model = YOLO(model=r'E:\Code\Detect_Datasets\YOLO\ultralytics-8.3.2-GJ0\ultralytics\cfg\models\11\yolo11-obb.yaml') # 模型配置文件的路径
    # model = YOLO(model=r'E:\Code\Detect_Datasets\YOLO\ultralytics-8.3.2-GJ0\ultralytics\cfg\models\11\yolo11-obb-ELA.yaml') # 模型配置文件的路径

    # model.load('yolo11s.pt')  # 做改进的话，不需要预训练模型权重，因为用预训练模型权重很难提高
    # model.load('./runs/train/exp13/weights/best.pt')  # 做改进的话，不需要预训练模型权重，因为用预训练模型权重很难提高
    # model.train(data=r'E:\Code\Detect_Datasets\YOLO\ultralytics-8.3.2\ultralytics\cfg\datasets\data.yaml',   # 数据集配置文件路径
    model.train(data=r'E:\Code\Detect_Datasets\YOLO\ultralytics-8.3.2-GJ0\ultralytics\cfg\datasets\data_obb.yaml',  # 数据集配置文件路径
    # model.train(data=r'E:\Code\Detect_Datasets\YOLO\ultralytics-8.3.2-GJ0\ultralytics\cfg\datasets\data_obb1_qx.yaml',  # 数据集配置文件路径
                imgsz=640,   # 输入图像的尺寸，指定640*640
                epochs=100,  # 训练轮数，官方默认时300
                batch=16,    # 批量大小，电脑性能好就填大一点，电脑显存越大，就设置的大一点 !!!
                workers=0,   # 工作的线程数
                # device='', # 用哪个显卡训练 GPU CPU
                device='0',  # 0代表使用的GPU显卡训练
                optimizer='SGD', # 优化器类型
                close_mosaic=10, # 任多少个epoch后关闭mosaic数据增强 ######################
                resume=False,
                project='runs/train', # 保留训练解决
                name='exp',  # 保存结果的文件夹
                single_cls=False,  # 是否将所有类被视为1个类
                cache=False, # 是否缓存数据，false代表不缓存
                )


