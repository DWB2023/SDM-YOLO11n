from ultralytics import YOLO

def export():
    # model = YOLO(r'runs/detect/train8/weights/best.pt')  # 加载模型 E:\Code\Detect_Datasets\Labelimg\13 X-AnyLabeling-main\models\best-obb.pt
    # model = YOLO(r'E:\Code\Detect_Datasets\Labelimg\13 X-AnyLabeling-main\models\best_obbtrain4.pt')  # 加载模型 E:\Code\Detect_Datasets\Labelimg\13 X-AnyLabeling-main\models\best-obb.pt
    # model = YOLO(r'E:\Code\Detect_Datasets\YOLO\ultralytics-8.3.2\zpwjj\models1\best-obb.pt')  # 加载模型 E:\Code\Detect_Datasets\Labelimg\13 X-AnyLabeling-main\models\best-obb.pt
    model = YOLO(r'E:\Code\Detect_Datasets\YOLO\ultralytics-8.3.2\runs\train\exp13\weights\best.pt')  # 加载模型 E:\Code\Detect_Datasets\Labelimg\13 X-AnyLabeling-main\models\best-obb.pt
    # model = YOLO(r'E:\Code\Detect_Datasets\Labelimg\13 X-AnyLabeling-main\models\best-obb.pt')  # 加载模型 E:\Code\Detect_Datasets\Labelimg\13 X-AnyLabeling-main\models\best-obb.pt
    model.export(format='onnx',  #导出onnx格式，默认原路径保存，例如:best.onnx
                 imgsz=640,  # 模型的图片输入尺寸
                 dynamic=False,  # 禁止模型动态的图片输入大小
                 )

if __name__ == '__main__':
    export()



'''
    表签自动标注：https://blog.csdn.net/weixin_45686120/article/details/144177943
    ImportError: DLL load failed while importing onnx_cpp2py_export : 动态链接库（DLL）初始化历程失败
                 https://blog.csdn.net/qq_38702496/article/details/141052666 

'''