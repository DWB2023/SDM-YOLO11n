# import sys
# sys.path.append('/ultralytics-main/ultralytics')
# from ultralytics.data.converter import convert_dota_to_yolo_obb
# convert_dota_to_yolo_obb('H:/dwb/yolov8/ultralytics-main1/myData')   #  # DOTA txt格式标签文件存放路径
# # 关于dataobb文件下的目录下面会详细说明
# # H:/dwb/yolov8/ultralytics-main1/myData


import sys
import inspect

# sys.path.insert(0, '/home/y/code/yolov8')
sys.path.insert(0, '/ultralytics-main1') # 可能修改的语句
print(sys.path)

from ultralytics.data.converter import convert_dota_to_yolo_obb

source_file = inspect.getsourcefile(convert_dota_to_yolo_obb)
print("convert_dota_to_yolo_obb 函数所在文件的路径：", source_file)
convert_dota_to_yolo_obb('./data/test_datasets11')
# 关于dataobb文件下的目录下面会详细说明   'H:/dwb/yolov8/ultralytics-main1/ultralytics/data/converter.py'  修改converter.py文件的510行！



