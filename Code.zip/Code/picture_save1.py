

import os
import threading
import cv2

def keyboard():
    global pzyx
    while True:
        choice = input("请输入数字选择操作：\n")
        if choice == '1':
            pzyx=1
        else:
            print("无效的选择，请重新输入")
if __name__ == '__main__':
    # url = 0
    url = "rtsp://admin:zhxfqwe111@111.115.7.66/Streaming/Channels/2"
    cap = cv2.VideoCapture(url)
    if not cap.isOpened():
        print("Error: 无法打开摄像头")
        exit()
    os.makedirs('zpwjj',exist_ok=True)
    i=0
    pzyx=0
    CurImg0 = threading.Thread(target=keyboard)
    CurImg0.daemon = 0
    CurImg0.start()
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: 无法读取摄像头数据")
            break
        # 显示实时检测结果
        cv2.imshow('Real-time Detection', frame)
        # time.sleep(500)
        # xh=input("请输入文件名序号：")
        if pzyx==1:
            i = i + 1
            pzyx=0
            # filename='./zpwjj/'+str(i)+'.bmp'
            filename='./zpwjj/'+str(i)+'.png'
            cv2.imwrite(filename,frame)
        # 按下 'q' 键退出循环
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()


